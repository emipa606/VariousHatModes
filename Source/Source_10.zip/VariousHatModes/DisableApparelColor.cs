﻿using Verse;

namespace VariousHatModes
{
    // Token: 0x02000005 RID: 5
    public class DisableApparelColor : ThingDef
    {
        // Token: 0x04000001 RID: 1
        public bool ApparelColor = true;
    }
}